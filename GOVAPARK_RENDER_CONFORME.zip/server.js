import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 10000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'dist', 'public')));

// Health check required by hosting platforms.
app.get('/health', (_req, res) => res.status(200).json({ status: 'ok', service: 'GOVAPARK' }));

// SPA fallback: React Router pages must all return index.html.
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'public', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`GOVAPARK running on port ${PORT}`);
});
