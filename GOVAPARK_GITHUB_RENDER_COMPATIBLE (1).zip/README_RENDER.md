# GOVAPARK — déploiement GitHub + Render

## Structure
Les fichiers `package.json`, `package-lock.json`, `render.yaml`, `index.html`, `src/` et `api/` sont directement à la racine du dépôt GitHub. Ne pas conserver un dossier parent `GOVAPARK/` autour du projet.

## Déploiement
1. Décompresser cette archive.
2. Envoyer **le contenu** du dossier (pas le dossier parent) dans un dépôt GitHub.
3. Dans Render, choisir **New + → Blueprint** et sélectionner ce dépôt. Render lira `render.yaml`.
   - Alternative : créer un **Web Service** avec `Build Command` = `npm ci && npm run build` et `Start Command` = `npm start`.
4. Vérifier que le service utilise Node 22.16.0 ou supérieur compatible Node 22.
5. Ajouter dans Render → Environment les variables nécessaires à votre configuration : `DATABASE_URL`, `APP_ID`, `APP_SECRET`, `KIMI_AUTH_URL`, `KIMI_OPEN_URL`, `OWNER_UNION_ID`, et les variables OAuth `VITE_KIMI_AUTH_URL` / `VITE_APP_ID` si l'authentification Kimi est utilisée.
6. Déployer.

## Important
- `render.yaml` configure le build et le démarrage du serveur Hono/Node.
- Le frontend Vite est construit dans `dist/public`; le serveur démarre depuis `dist/boot.js`.
- Les fonctions qui nécessitent une base MySQL ou des identifiants externes ne fonctionneront pas tant que les variables correspondantes ne sont pas renseignées.
- Cette archive prépare le déploiement, mais ne certifie pas les paiements réels, les autorisations de stationnement ni les intégrations externes.
