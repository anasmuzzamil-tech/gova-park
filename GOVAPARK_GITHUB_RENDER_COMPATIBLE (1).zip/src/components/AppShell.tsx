import { NavLink, Outlet, useLocation, Navigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { Map, CalendarDays, CirclePlus, UserRound, ParkingSquare, MessageCircle, ShieldCheck, CarFront } from "lucide-react";

const nav = [
  { to: "/", label: "Carte", icon: Map },
  { to: "/reservations", label: "Réservations", icon: CalendarDays },
  { to: "/messages", label: "Messages", icon: MessageCircle },
  { to: "/mobilite", label: "Mobilité", icon: CarFront },
  { to: "/profil", label: "Paramètres", icon: UserRound },
];

export default function AppShell() {
  const location = useLocation();
  const { user, isAuthenticated, isLoading } = useAuth();
  const visibleNav = user?.role === "admin" ? [...nav, { to: "/entreprise", label: "Espace société", icon: ParkingSquare }, { to: "/admin", label: "Modération", icon: ShieldCheck }] : user?.role === "owner" ? [...nav, { to: "/proposer", label: "Espace propriétaire", icon: CirclePlus }] : [...nav, { to: "/espace-client", label: "Mon espace", icon: UserRound }];
  const isMap = location.pathname === "/";
  if (isLoading) return <div className="page-loading"><span className="loader" />Ouverture de votre espace GOVAPARK…</div>;
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return (
    <div className="app-shell">
      <aside className="desktop-rail">
        <NavLink to="/" className="brand" aria-label="Govapark, accueil"><span className="brand-mark"><ParkingSquare size={22} /></span><span>Govapark</span></NavLink>
        <p className="rail-caption">Le stationnement partagé<br />en Île-de-France.</p>
        <nav className="rail-nav" aria-label="Navigation principale">
          {visibleNav.map(({ to, label, icon: Icon }) => <NavLink key={to} to={to} className={({ isActive }) => isActive ? "active" : ""}><Icon size={19} /><span>{label}</span></NavLink>)}
        </nav>
        <div className="rail-note"><span className="live-dot" />Données de démonstration<br /><small>Paiement désactivé</small></div>
      </aside>
      <main className={`app-main ${isMap ? "map-main" : ""}`}><Outlet /></main>
      <nav className="bottom-nav" style={{ gridTemplateColumns: `repeat(${visibleNav.length}, minmax(0, 1fr))` }} aria-label="Navigation principale">
        {visibleNav.map(({ to, label, icon: Icon }) => <NavLink key={to} to={to} className={({ isActive }) => isActive ? "active" : ""}><Icon size={21} strokeWidth={isMap && to === "/" ? 2.4 : 2} /><span>{label}</span></NavLink>)}
      </nav>
    </div>
  );
}
