import { useEffect, useRef } from "react";
import { MapContainer, Marker, useMap, TileLayer, Circle, CircleMarker, Popup, Polyline } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

export type MapListing = {
  id: number;
  title: string;
  latitude: number;
  longitude: number;
  currentAvailability?: "available" | "unavailable" | "unknown";
  hourlyCents?: number;
  approxAddress?: string;
};
export type MapReport = {
  id: number;
  kind: "free" | "occupied" | "departure";
  latitude: number;
  longitude: number;
  address: string;
};
type Center = { lat: number; lng: number };
type GpsPosition = Center & { accuracy?: number };
type RouteService = { id:string; lat:number; lng:number; name:string; kind:"charge"|"rest"|"parking"|"truck"|"restaurant"|"fuel"; detail?:string; price?:number; priceUpdated?:string };

function Recenter({ center }: { center: Center }) {
  const map = useMap();
  const previous = useRef(center);
  useEffect(() => {
    const changed = previous.current.lat !== center.lat || previous.current.lng !== center.lng;
    previous.current = center;
    if (!changed) return;
    map.flyTo([center.lat, center.lng], Math.max(map.getZoom(), 14), { duration: 0.45 });
  }, [center, map]);
  return null;
}

function markerIcon(color: string, text: string, label: string) {
  const safeLabel = label.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character] ?? character);
  return L.divIcon({
    className: "govapark-marker-wrap",
    html: `<span class="map-marker marker-${color}" aria-label="${safeLabel}"><span class="marker-symbol">${text}</span></span>`,
    iconSize: [38, 46],
    iconAnchor: [19, 42],
    popupAnchor: [0, -40],
  });
}

export default function ParkingMap({
  center, listings, reports, confirmedIds, onListing, onBook, onRoute, onReport, onMove, userPosition, routeCoordinates, routeListingIds, routeServices = [], fuelStations = [], vehicleType = "car", vehicleColor = "#2563eb",
}: {
  center: Center;
  listings: MapListing[];
  reports: MapReport[];
  confirmedIds: Set<number>;
  onListing: (id: number) => void;
  onBook: (id: number) => void;
  onRoute: (id: number) => void;
  routeCoordinates?: [number, number][];
  routeListingIds?: Set<number>;
  routeServices?: RouteService[];
  onReport: (report: MapReport) => void;
  onMove?: (center: Center) => void;
  userPosition?: GpsPosition | null;
  fuelStations?: Array<{id:number;lat:number;lng:number;name:string}>;
  vehicleType?: string; vehicleColor?: string;
}) {
  return (
    <MapContainer center={[center.lat, center.lng]} zoom={11} zoomControl={false} className="parking-map" scrollWheelZoom minZoom={3} maxZoom={19}>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        maxZoom={19}
      />
      <Recenter center={center} />
      <MapMove onMove={onMove} />
      {routeCoordinates && routeCoordinates.length > 1 && <Polyline positions={routeCoordinates} pathOptions={{ color: "#1769aa", weight: 6, opacity: 0.82 }} />}
      {userPosition && <>
        <Circle
          center={[userPosition.lat, userPosition.lng]}
          radius={Math.max(20, Math.min(userPosition.accuracy ?? 35, 120))}
          pathOptions={{ color: "#2563eb", fillColor: "#60a5fa", fillOpacity: 0.12, weight: 1 }}
        />
        <CircleMarker
          center={[userPosition.lat, userPosition.lng]}
          radius={8}
          pathOptions={{ color: "#ffffff", weight: 3, fillColor: vehicleColor, fillOpacity: 1 }}
        ><Popup>Votre position GPS · {vehicleType}</Popup></CircleMarker>
      </>}
      {listings.map((listing) => {
        const statusColor = listing.currentAvailability === "available"
          ? "green"
          : listing.currentAvailability === "unavailable"
            ? "red"
            : confirmedIds.has(listing.id) ? "blue" : "violet";
        const statusText = listing.currentAvailability === "available"
          ? "Disponible actuellement"
          : listing.currentAvailability === "unavailable"
            ? "Indisponible actuellement"
            : "Disponibilité à vérifier";
        return <Marker
          key={`l-${listing.id}`}
          position={[listing.latitude, listing.longitude]}
          title={`${listing.title} — ${statusText}`}
          icon={markerIcon(statusColor, "P", `${listing.title} — ${statusText}`)}
        >
          <Popup>
            <div className="map-listing-popup"><strong>{listing.title}</strong><span>{statusText}</span>{listing.approxAddress && <small>{listing.approxAddress}</small>}
              {routeListingIds?.has(listing.id) && <small className="route-nearby-tag">Sur votre trajet</small>}
              <div className="map-popup-actions"><button type="button" onClick={() => onRoute(listing.id)}>Itinéraire</button><button type="button" onClick={() => onBook(listing.id)}>Réserver</button></div>
            </div>
          </Popup>
        </Marker>;
      })}
      {routeServices.map((service) => {
        const symbol = service.kind === "charge" ? "⚡" : service.kind === "rest" ? "🛣" : service.kind === "truck" ? "🚛" : service.kind === "restaurant" ? "🍴" : service.kind === "parking" ? "P" : "⛽";
        const color = service.kind === "charge" ? "green" : service.kind === "truck" ? "orange" : service.kind === "fuel" ? "blue" : "violet";
        return <Marker key={service.id} position={[service.lat,service.lng]} icon={markerIcon(color,symbol,service.name)}><Popup><strong>{service.name}</strong><br/>{service.kind === "charge" ? "Borne de recharge électrique" : service.kind === "rest" ? "Aire de repos ou de service" : service.kind === "truck" ? "Infrastructure poids lourds signalée" : service.kind === "restaurant" ? "Restauration" : service.kind === "parking" ? "Parking" : "Station-service"}{service.price != null && <><br/><strong>{service.price.toFixed(3)} €/L</strong><br/><small>Prix officiel · mise à jour {service.priceUpdated ? new Date(service.priceUpdated).toLocaleString("fr-FR") : "non précisée"}</small></>}{service.detail && <><br/><small>{service.detail}</small></>}</Popup></Marker>;
      })}
      {fuelStations.map((station) => <Marker key={`fuel-${station.id}`} position={[station.lat,station.lng]} icon={markerIcon("blue", "⛽", station.name)}><Popup><strong>{station.name}</strong><br/>Station-service · données OpenStreetMap</Popup></Marker>)}
      {reports.map((report) => {
        const color = report.kind === "free" ? "green" : report.kind === "occupied" ? "red" : "orange";
        const text = report.kind === "free" ? "✓" : report.kind === "occupied" ? "×" : "↗";
        return <Marker
          key={`r-${report.id}`}
          position={[report.latitude, report.longitude]}
          title={report.address}
          icon={markerIcon(color, text, report.address)}
          eventHandlers={{ click: () => onReport(report) }}
        />;
      })}
    </MapContainer>
  );
}

function MapMove({ onMove }: { onMove?: (center: Center) => void }) {
  const map = useMap();
  useEffect(() => {
    if (!onMove) return;
    const handler = () => {
      const value = map.getCenter();
      onMove({ lat: value.lat, lng: value.lng });
    };
    map.on("moveend", handler);
    return () => { map.off("moveend", handler); };
  }, [map, onMove]);
  return null;
}
